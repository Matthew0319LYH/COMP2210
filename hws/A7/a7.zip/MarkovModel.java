import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.io.IOException;
import java.util.Random;

/**
 * MarkovModel.java
 * Creates an order K Markov model of the supplied source text.
 * The value of K determines the size of the "kgrams" used
 * to generate the model. A kgram is a sequence of k consecutive
 * characters in the source text.
 *
 * @author     YOUR NAME (you@auburn.edu)
 * @author     Dean Hendrix (dh@auburn.edu)
 * @version    2015-11-16
 *
 */
public class MarkovModel {

   /**
    * Construct the order K model of the file sourceText.
    */
   public MarkovModel(int K, File sourceText) {

   }


   /**
    * Construct the order K model of the string sourceText.
    */
   public MarkovModel(int K, String sourceText) {

   }


   /** Return the first kgram found in the source text. */
   public String firstKgram() {
      return "";
   }


   /** Return a random kgram from the source text. */
   public String randomKgram() {
      return "";
   }


   /**
    * Return a single character that follows the given
    * kgram in the source text. Select this character
    * according to the probability distribution of all
    * characters the follow the given kgram in the
    * source text.
    */
   public char nextChar(String kgram) {
      return '\u0000';
   }

}
